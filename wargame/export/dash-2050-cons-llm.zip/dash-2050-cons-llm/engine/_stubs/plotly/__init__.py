"""Stub used only when plotly is not installed: the engine never draws, it only computes."""
