"""Game-master command line for dash-2050 (the GM only; players are blocked from this folder and from wargame/runs).

  python3 gm.py init [objective_set] [--sd] [--sd-options=FILE]
                                          # new run: state_r0.json, public rules to each player's folder; e.g. control2;
                                          # --sd switches on supply and demand (supply_demand.py) for the run;
                                          # --sd-options copies FILE to the run's sd_options.json (supply_demand.options)
  python3 gm.py brief N                   # bulletin + private briefs for round N (from state after round N-1)
  python3 gm.py adjudicate N orders.json  # validate and adjudicate round N; writes state_rN.json and the record
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import briefs as B  # noqa: E402
import model as M  # noqa: E402
import rules as R  # noqa: E402

RUN = os.environ.get("DASH_RUN", "dash-2050")
RUN_DIR = os.path.join(HERE, "..", "runs", RUN)
ROUNDS = R.ROUNDS


def pdir(side):
    return os.path.join(RUN_DIR, "players", side)


def jload(name):
    with open(os.path.join(RUN_DIR, name)) as f:
        return json.load(f)


def jsave(name, obj):
    with open(os.path.join(RUN_DIR, name), "w") as f:
        json.dump(obj, f, indent=1, default=str)


def init(objective_set=None, sd=False, sd_options=None):
    os.makedirs(RUN_DIR, exist_ok=True)
    opt = os.path.join(RUN_DIR, "sd_options.json")
    if sd_options:                         # the run's own supply-and-demand options, before the rules are written
        with open(sd_options) as f:
            x = json.load(f)
        with open(opt, "w") as f:
            json.dump(x, f, indent=1)
    elif os.path.exists(opt):
        os.remove(opt)
    M.SD.reload()
    flag = os.path.join(RUN_DIR, "supply_demand.txt")
    if sd:                                 # supply and demand (supply_demand.py) for this run; model.py reads the flag
        with open(flag, "w") as f:
            f.write("on\n")
        M.SD_ON = True                     # this process too (model.py read the flag before it existed)
    elif os.path.exists(flag):
        os.remove(flag)
        M.SD_ON = False
    with open(os.path.join(RUN_DIR, "board.txt"), "w") as f:
        f.write(M.H.VERSION + "\n")       # the run keeps this board version (model.py reads it back)
    if objective_set:                      # e.g. control2: Control's added objectives (briefs.objective_set reads it)
        with open(os.path.join(RUN_DIR, "objectives.txt"), "w") as f:
            f.write(objective_set + "\n")
    s = M.new_state()
    jsave("state_r0.json", s)
    rules_txt = B.public_rules()
    with open(os.path.join(RUN_DIR, "rules.md"), "w") as f:
        f.write(rules_txt)
    for side in M.SIDES:
        os.makedirs(pdir(side), exist_ok=True)
        with open(os.path.join(pdir(side), "rules.md"), "w") as f:
            f.write(rules_txt)
    print("initialised", RUN_DIR, "on board", M.H.VERSION, os.path.basename(M.H.SRC))


def brief(n):
    year = ROUNDS[n - 1]
    s = jload("state_r%d.json" % (n - 1))
    rec = jload("record_r%d.json" % (n - 1)) if n > 1 else {}
    statements = rec.get("public_statements")
    public_other = rec.get("public_other_moves")
    gm_notes = rec.get("bulletin_notes")
    bul = B.bulletin(s, year, n, statements, public_other, gm_notes)
    with open(os.path.join(RUN_DIR, "bulletin_r%d.md" % n), "w") as f:
        f.write(bul)
    grids = {}
    for side in M.SIDES:
        notes = (rec.get("private_notes") or {}).get(side)
        txt, grid, scen = B.private_brief(s, side, year, n, gm_notes=notes)
        full = bul + "\n\n---\n\n" + txt
        os.makedirs(pdir(side), exist_ok=True)
        with open(os.path.join(pdir(side), "round%d.md" % n), "w") as f:
            f.write(full)
        with open(os.path.join(RUN_DIR, "brief_r%d_%s.md" % (n, side)), "w") as f:
            f.write(full)
        grids[side] = {"scenarios": [x[0] for x in scen],
                       "rows": [{"plan": g[0], "orders": g[1], "cells": g[2]} for g in grid]}
        print(side, "brief written:", len(full), "chars;", len(grid), "plans x", len(scen), "scenarios")
    if M.SD_ON:                            # the standing supply plans, for the round script (args.plans)
        sd_ = s.get("sd") or {}
        print("supply plans (pass as args.plans to workflows/exco_round.js):",
              json.dumps({"boeing": {"fps_site": sd_.get("fps_site", "new_site")}, "airbus": {"a320_plan": sd_.get("a320_plan", "base")}}))
    jsave("grids_r%d.json" % n, grids)


def adjudicate(n, orders_path):
    year = ROUNDS[n - 1]
    s = jload("state_r%d.json" % (n - 1))
    with open(orders_path) as f:
        returned = json.load(f)
    orders, problems = {}, {}
    for side in M.SIDES:
        o = (returned.get(side) or {}).get("orders", {})
        clean, probs = R.validate(s, side, year, o)
        orders[side] = clean
        problems[side] = probs
    s1, log = R.adjudicate(s, year, orders)
    jsave("state_r%d.json" % n, s1)
    v = M.value(s1, covert=True, series=False)
    vpub = M.value(s1, covert=False, series=False)
    statements = {side: (returned.get(side) or {}).get("public_statement", "") for side in M.SIDES}
    public_other, private_other = {}, {}
    for side in M.SIDES:
        for it in (returned.get(side) or {}).get("other_moves", []) or []:
            (public_other if it.get("public") else private_other).setdefault(side, []).append(it)
    public_log = [e for e in log if "[covert]" not in e and "conditional launch" not in e]
    notes = ["Round %d (%d) adjudicated. Public events: %s." % (n, year, "; ".join(public_log) if public_log else "none")]
    rec = {"round": n, "year": year, "orders": orders, "problems": problems, "log": log,
           "public_statements": statements, "public_other_moves": public_other, "private_other_moves": private_other,
           "bulletin_notes": notes,
           "private_notes": {side: ["Your round-%d orders were adjusted: %s" % (n, "; ".join(problems[side]))]
                             for side in M.SIDES if problems[side]},
           "value": {side: {"pv_delta": v[side]["pv_delta"], "yield": v[side]["yield"]} for side in M.SIDES},
           "value_public_view": {side: {"pv_delta": vpub[side]["pv_delta"], "yield": vpub[side]["yield"]} for side in M.SIDES},
           "returned": returned}
    jsave("record_r%d.json" % n, rec)
    for side in M.SIDES:   # each player keeps its own sealed orders and reasoning (nobody else's)
        with open(os.path.join(pdir(side), "my_orders_r%d.json" % n), "w") as f:
            json.dump({"round": n, "year": year, "as_returned": returned.get(side), "as_adjudicated": orders[side],
                       "adjustments": problems[side]}, f, indent=1)
    print("round", n, year, "adjudicated")
    for e in log:
        print("  -", e)
    for side in M.SIDES:
        if problems[side]:
            print("  !", side, problems[side])
    for side in M.SIDES:
        print("  %-14s ΔPV %+8.2f  yield %6.2f%%" % (side, v[side]["pv_delta"], v[side]["yield"]))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "init":
        args = [a for a in sys.argv[2:] if not a.startswith("--sd")]
        so = [a.split("=", 1)[1] for a in sys.argv[2:] if a.startswith("--sd-options=")]
        init(args[0] if args else None, sd="--sd" in sys.argv, sd_options=so[0] if so else None)
    elif cmd == "brief":
        brief(int(sys.argv[2]))
    elif cmd == "adjudicate":
        adjudicate(int(sys.argv[2]), sys.argv[3])
